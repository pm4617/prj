package org.markelgroup.mol;

 

import org.testng.annotations.Test;
import  lib.polib.*;
import lib.polib.LoginPage;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;

public class NewTest {
	
	public static FirefoxDriver driver ;
	public  LoginPage loginpage ;
	public String URL;  
	
  @Test
  public void f() {
	  
	  //LoginPage.searchtextbox().click();	 
	  LoginPage.userid().click();
	  //loginpage.userid().click();
	  LoginPage.userid().sendKeys("Test");
	  
  }
  
  @BeforeTest
  public void beforeTest()  {
	  try {
		PropertyReader pr = new PropertyReader("src/main/java/config/molconfig.properties");
		URL= pr.getProperty("uwurl");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   driver = new  FirefoxDriver();
	  driver.get(URL);
	  loginpage = new LoginPage(driver);
  }

}
