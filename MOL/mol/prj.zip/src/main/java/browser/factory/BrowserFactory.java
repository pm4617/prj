package browser.factory;

public class BrowserFactory {

}
